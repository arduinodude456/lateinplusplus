import tkinter as tk
from tkinter import messagebox, simpledialog, filedialog
import json
import os

class VokabelEditor:
    def __init__(self, root):
        self.root = root
        self.root.title("Vokabel-Lektion Editor")

        # Listen für Entry-Widgets
        self.vokabel_entries = []
        self.antwort_entries = []

        # Menü
        menubar = tk.Menu(root)
        filemenu = tk.Menu(menubar, tearoff=0)
        filemenu.add_command(label="Speichern", command=self.speichern)
        menubar.add_cascade(label="Datei", menu=filemenu)
        root.config(menu=menubar)

        # Frames
        self.frame = tk.Frame(root)
        self.frame.pack(padx=10, pady=10)

        tk.Label(self.frame, text="Vokabel").grid(row=0, column=0, padx=5)
        tk.Label(self.frame, text="Übersetzung").grid(row=0, column=1, padx=5)

        # Buttons
        btn_frame = tk.Frame(root)
        btn_frame.pack(pady=10)

        tk.Button(btn_frame, text="Neu", command=self.neu).grid(row=0, column=0, padx=10)
        tk.Button(btn_frame, text="Löschen", command=self.loeschen).grid(row=0, column=1, padx=10)

        # Start mit einem Eintrag
        self.neu()

    def neu(self):
        """Fügt ein neues Vokabelpaar hinzu."""
        row = len(self.vokabel_entries) + 1

        vok_entry = tk.Entry(self.frame, width=25)
        ant_entry = tk.Entry(self.frame, width=25)

        vok_entry.grid(row=row, column=0, padx=5, pady=3)
        ant_entry.grid(row=row, column=1, padx=5, pady=3)

        self.vokabel_entries.append(vok_entry)
        self.antwort_entries.append(ant_entry)

    def loeschen(self):
        """Löscht das letzte Vokabelpaar."""
        if not self.vokabel_entries:
            return

        self.vokabel_entries[-1].destroy()
        self.antwort_entries[-1].destroy()

        self.vokabel_entries.pop()
        self.antwort_entries.pop()

    def speichern(self):
        """Speichert die Lektion in zwei .vu-Dateien."""
        lektion_name = simpledialog.askstring("Lektion speichern", "Name der Lektion:")

        if not lektion_name:
            return

        # Ordner erstellen
        os.makedirs("Lektion", exist_ok=True)

        # Daten sammeln
        vokabeln = [e.get() for e in self.vokabel_entries]
        antworten = [e.get() for e in self.antwort_entries]

        # Dateien speichern
        datei_f = os.path.join("Lektion", f"{lektion_name}_f.vu")
        datei_a = os.path.join("Lektion", f"{lektion_name}_a.vu")

        with open(datei_f, "w", encoding="utf-8") as f:
            json.dump(vokabeln, f, ensure_ascii=False, indent=2)

        with open(datei_a, "w", encoding="utf-8") as f:
            json.dump(antworten, f, ensure_ascii=False, indent=2)

        messagebox.showinfo("Gespeichert", f"Lektion '{lektion_name}' wurde gespeichert!")

# Hauptprogramm starten
root = tk.Tk()
app = VokabelEditor(root)
root.mainloop()
